
// An enumeration for a very simple
// state machine used in this example
public enum Task
{
    Pathfinding,
    Move,
    SetTarget,
    Idle,
    Return,
    Refresh
}