using UnityEngine;

public class Agent : MonoBehaviour
{
    public ForageItem target;
}
